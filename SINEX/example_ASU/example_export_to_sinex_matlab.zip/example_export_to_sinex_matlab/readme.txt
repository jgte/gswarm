Sample code to export the normal equation matrix related to gravity field solutions
in the SINEX for the DISC consortium according to guidelines provided by https://jgte.github.io/gswarm/SINEX/.

After running sinex_asu_01c.m, one should obtain the file 'GSWARM_NE_SABC_ASU_2014-08_01_IFG.snx'.

The code is free to use, in its entirety or in parts.

Ales Bezdek, bezdek@asu.cas.cz, 15. 3. 2018
